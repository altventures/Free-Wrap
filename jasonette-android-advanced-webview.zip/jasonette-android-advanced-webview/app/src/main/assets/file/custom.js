/*
This file is loaded automatically on $webcontainer.
Use it to modify the website with javascript.
*/

console.log("file://custom.js loaded");